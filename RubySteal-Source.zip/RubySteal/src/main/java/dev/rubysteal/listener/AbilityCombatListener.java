package dev.rubysteal.listener;

import dev.rubysteal.RubyStealPlugin;
import dev.rubysteal.core.AbilityManager;
import dev.rubysteal.model.PlayerData;
import org.bukkit.Particle;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;

/** Phoenix Rebirth (level 10 passive) and lifesteal hits (Blood Pact / Ruby Awakening). */
public final class AbilityCombatListener implements Listener {
    private final RubyStealPlugin plugin;

    public AbilityCombatListener(RubyStealPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onLethal(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (p.getHealth() - e.getFinalDamage() > 0) return;
        if (plugin.getConfig().getStringList("phoenix.ignored-causes").contains(e.getCause().name())) return;
        PlayerData d = plugin.ruby().cached(p.getUniqueId());
        if (d == null) return;
        if (plugin.abilities().tryPhoenix(p, d)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p) || !(e.getEntity() instanceof LivingEntity victim) || victim.equals(p)) return;
        AbilityManager.Buff b = plugin.abilities().lifestealOf(p.getUniqueId());
        if (b == null) return;
        if (plugin.getConfig().getBoolean("abilities.lifesteal-players-only", true) && !(victim instanceof Player)) return;
        double heal = Math.min(b.cap(), e.getFinalDamage() * b.ratio());
        if (heal <= 0) return;
        AttributeInstance attr = p.getAttribute(Attribute.MAX_HEALTH);
        double max = attr == null ? 20.0 : attr.getValue();
        p.setHealth(Math.min(max, p.getHealth() + heal));
        p.getWorld().spawnParticle(Particle.HEART, p.getLocation().add(0, 1.8, 0), 2, 0.3, 0.2, 0.3, 0.0);
    }
}
