package dev.rubysteal.core;

import dev.rubysteal.RubyStealPlugin;
import dev.rubysteal.model.AbilityDef;
import dev.rubysteal.model.AbilityDef.EffectSpec;
import dev.rubysteal.model.AbilityDef.Type;
import dev.rubysteal.model.PlayerData;
import dev.rubysteal.util.Text;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Tameable;
import org.bukkit.entity.Villager;
import org.bukkit.entity.WanderingTrader;
import org.bukkit.util.RayTraceResult;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permission;
import org.bukkit.permissions.PermissionDefault;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scoreboard.Team;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class AbilityManager {
    private final RubyStealPlugin plugin;
    private volatile List<AbilityDef> defs = List.of();
    private final Map<UUID, String> selected = new ConcurrentHashMap<>();
    private final Map<UUID, Map<String, Integer>> usesThisLife = new ConcurrentHashMap<>();
    private final Map<UUID, Long> lastUse = new ConcurrentHashMap<>();
    private final Map<UUID, Buff> lifesteal = new ConcurrentHashMap<>();
    private final Map<UUID, Long> awakened = new ConcurrentHashMap<>();

    public static final String PHOENIX = "phoenix_rebirth";

    /** Temporary lifesteal: heals ratio * damage dealt per hit, capped. */
    public record Buff(long until, double ratio, double cap) {}

    public AbilityManager(RubyStealPlugin plugin) {
        this.plugin = plugin;
    }

    public void reload() {
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("abilities.list");
        List<AbilityDef> out = new ArrayList<>();
        if (sec != null) {
            for (String id : sec.getKeys(false)) {
                ConfigurationSection s = sec.getConfigurationSection(id);
                if (s == null || !s.getBoolean("enabled", true)) continue;
                Type type;
                try {
                    type = Type.valueOf(s.getString("type", "EFFECT").toUpperCase());
                } catch (IllegalArgumentException e) {
                    plugin.getLogger().warning("Ability '" + id + "' has unknown type, skipped.");
                    continue;
                }
                List<EffectSpec> effects = new ArrayList<>();
                for (Map<?, ?> m : s.getMapList("effects")) {
                    String name = String.valueOf(m.get("type"));
                    PotionEffectType pet = PotionEffectType.getByKey(NamespacedKey.minecraft(name.toLowerCase()));
                    if (pet == null) {
                        plugin.getLogger().warning("Ability '" + id + "': unknown effect '" + name + "'");
                        continue;
                    }
                    int amp = m.get("amplifier") instanceof Number n ? n.intValue() : 0;
                    double secs = m.get("seconds") instanceof Number n ? n.doubleValue() : 5;
                    effects.add(new EffectSpec(pet, Math.max(0, amp), (int) Math.max(1, secs * 20)));
                }
                out.add(new AbilityDef(id.toLowerCase(), s.getString("name", id), s.getString("description", ""), type,
                        s.getInt("unlock-level", 1), Math.max(0, s.getInt("cooldown-seconds", 30)),
                        s.getBoolean("block-in-combat", false), s.getInt("uses-per-life", 0),
                        s.getString("sound", ""), effects, s.getDouble("power", 1.5), s.getDouble("vertical", 0.3),
                        s.getDouble("amount", 4.0), s.getDouble("radius", 6.0), s.getBoolean("include-self", true), s));
            }
        }
        out.sort((a, b) -> Integer.compare(a.unlockLevel(), b.unlockLevel()));
        defs = List.copyOf(out);
        if (plugin.getServer().getPluginManager().getPermission("rubysteal.ability." + PHOENIX) == null) {
            plugin.getServer().getPluginManager().addPermission(
                    new Permission("rubysteal.ability." + PHOENIX, "Phoenix Rebirth passive", PermissionDefault.TRUE));
        }
        // Bukkit denies unregistered nodes, so every configured ability gets a default-true permission.
        for (AbilityDef a : out) {
            String node = "rubysteal.ability." + a.id();
            if (plugin.getServer().getPluginManager().getPermission(node) == null) {
                plugin.getServer().getPluginManager().addPermission(
                        new Permission(node, "Use the " + a.name() + " ability", PermissionDefault.TRUE));
            }
        }
    }

    public List<AbilityDef> defs() {
        return defs;
    }

    public AbilityDef byId(String id) {
        for (AbilityDef a : defs) if (a.id().equalsIgnoreCase(id)) return a;
        return null;
    }

    public List<AbilityDef> unlocked(PlayerData d) {
        List<AbilityDef> out = new ArrayList<>();
        for (AbilityDef a : defs) if (a.unlockLevel() <= d.level) out.add(a);
        return out;
    }

    public AbilityDef selected(Player p, PlayerData d) {
        List<AbilityDef> list = unlocked(d);
        if (list.isEmpty()) return null;
        String id = selected.get(p.getUniqueId());
        for (AbilityDef a : list) if (a.id().equals(id)) return a;
        AbilityDef first = list.get(0);
        selected.put(p.getUniqueId(), first.id());
        return first;
    }

    public long remaining(PlayerData d, AbilityDef a) {
        Long exp = d.cooldowns.get(a.id());
        return exp == null ? 0 : Math.max(0, exp - System.currentTimeMillis());
    }

    public void clearLife(UUID id) {
        usesThisLife.remove(id);
        lifesteal.remove(id);
        awakened.remove(id);
    }

    public void forget(UUID id) {
        selected.remove(id);
        usesThisLife.remove(id);
        lastUse.remove(id);
        lifesteal.remove(id);
        awakened.remove(id);
    }

    /** Right-click handler: sneak cycles the selected ability, otherwise activates it. */
    public void handleUse(Player p) {
        long now = System.currentTimeMillis();
        Long last = lastUse.get(p.getUniqueId());
        if (last != null && now - last < 250) return; // double-fire / auto-click guard
        lastUse.put(p.getUniqueId(), now);
        PlayerData d = plugin.ruby().get(p);
        if (d == null) return;
        List<AbilityDef> list = unlocked(d);
        if (list.isEmpty()) {
            plugin.messages().send(p, "no-abilities");
            return;
        }
        if (p.isSneaking()) {
            AbilityDef cur = selected(p, d);
            int idx = list.indexOf(cur);
            AbilityDef next = list.get((idx + 1) % list.size());
            selected.put(p.getUniqueId(), next.id());
            plugin.messages().send(p, "ability-selected", "ability", next.name());
            p.playSound(p.getLocation(), "ui.button.click", 0.6f, 1.4f);
            return;
        }
        activate(p, d, selected(p, d));
    }

    public boolean activate(Player p, PlayerData d, AbilityDef a) {
        if (a == null) return false;
        if (!p.hasPermission("rubysteal.use") || !p.hasPermission("rubysteal.ability." + a.id())) {
            plugin.messages().send(p, "no-permission");
            return false;
        }
        if (plugin.getConfig().getStringList("abilities.disabled-worlds").contains(p.getWorld().getName())) {
            plugin.messages().send(p, "ability-world-disabled");
            return false;
        }
        if (a.blockInCombat() && plugin.abuse().inCombat(p) && !p.hasPermission("rubysteal.bypass.combat")) {
            plugin.messages().send(p, "ability-blocked-combat", "ability", a.name());
            return false;
        }
        long rem = remaining(d, a);
        if (rem > 0) {
            plugin.messages().send(p, "ability-cooldown", "ability", a.name(), "time", Text.time(rem));
            p.playSound(p.getLocation(), "block.note_block.bass", 0.6f, 0.7f);
            return false;
        }
        Map<String, Integer> uses = usesThisLife.computeIfAbsent(p.getUniqueId(), k -> new HashMap<>());
        if (a.usesPerLife() > 0 && uses.getOrDefault(a.id(), 0) >= a.usesPerLife()) {
            plugin.messages().send(p, "ability-no-uses", "ability", a.name(), "max", a.usesPerLife());
            return false;
        }
        boolean ok = apply(p, a);
        if (!ok) return false;
        if (a.usesPerLife() > 0) uses.merge(a.id(), 1, Integer::sum);
        if (a.cooldownSeconds() > 0) d.cooldowns.put(a.id(), System.currentTimeMillis() + a.cooldownSeconds() * 1000L);
        plugin.messages().send(p, "ability-used", "ability", a.name(), "cooldown", a.cooldownSeconds());
        if (!a.sound().isBlank()) p.getWorld().playSound(p.getLocation(), a.sound(), 1f, 1f);
        plugin.ruby().level(d.level).particle().play(p.getLocation(), plugin.getConfig().getInt("abilities.burst-multiplier", 8));
        plugin.ruby().saveAsync(d); // persists the cooldown immediately
        return true;
    }

    private boolean apply(Player p, AbilityDef a) {
        switch (a.type()) {
            case EFFECT -> {
                for (EffectSpec e : a.effects()) addEffect(p, e);
                return true;
            }
            case BLINK -> {
                return blink(p, a);
            }
            case LIFESTEAL -> {
                long until = System.currentTimeMillis() + a.raw().getInt("duration-seconds", 12) * 1000L;
                lifesteal.put(p.getUniqueId(), new Buff(until, a.raw().getDouble("ratio", 0.35),
                        a.raw().getDouble("max-heal-per-hit", 4.0)));
                return true;
            }
            case NOVA -> {
                nova(p, a.raw());
                return true;
            }
            case AWAKENING -> {
                for (EffectSpec e : a.effects()) addEffect(p, e);
                long until = System.currentTimeMillis() + a.raw().getInt("duration-seconds", 20) * 1000L;
                awakened.put(p.getUniqueId(), until);
                lifesteal.put(p.getUniqueId(), new Buff(until, a.raw().getDouble("lifesteal-ratio", 0.4),
                        a.raw().getDouble("lifesteal-cap", 4.0)));
                if (a.raw().getBoolean("lightning-effect", true)) p.getWorld().strikeLightningEffect(p.getLocation());
                nova(p, a.raw());
                return true;
            }
            case AURA -> {
                if (a.includeSelf()) for (EffectSpec e : a.effects()) addEffect(p, e);
                Team team = p.getScoreboard().getEntryTeam(p.getName());
                int affected = 0;
                int cap = plugin.getConfig().getInt("abilities.aura-max-targets", 8);
                for (Player o : p.getWorld().getPlayers()) {
                    if (o == p || affected >= cap) continue;
                    if (o.getLocation().distanceSquared(p.getLocation()) > a.radius() * a.radius()) continue;
                    Team ot = o.getScoreboard().getEntryTeam(o.getName());
                    if (team == null || ot == null || !team.getName().equals(ot.getName())) continue;
                    for (EffectSpec e : a.effects()) addEffect(o, e);
                    plugin.messages().send(o, "aura-received", "player", p.getName(), "ability", a.name());
                    affected++;
                }
                return true;
            }
            case PULSE -> {
                Vector dir = p.getLocation().getDirection().setY(0);
                if (dir.lengthSquared() < 1.0E-4) dir = new Vector(0, 0, 0);
                else dir.normalize().multiply(a.power());
                double max = plugin.getConfig().getDouble("abilities.max-pulse-velocity", 2.5);
                if (dir.length() > max) dir.normalize().multiply(max);
                dir.setY(Math.max(0, a.vertical()));
                p.setVelocity(dir);
                p.setFallDistance(0f);
                return true;
            }
            case HEAL -> {
                AttributeInstance attr = p.getAttribute(Attribute.MAX_HEALTH);
                double max = attr == null ? 20.0 : attr.getValue();
                if (p.getHealth() >= max) {
                    plugin.messages().send(p, "heal-full");
                    return false;
                }
                p.setHealth(Math.min(max, p.getHealth() + Math.max(0, a.amount())));
                return true;
            }
        }
        return false;
    }

    private void addEffect(Player p, EffectSpec e) {
        p.addPotionEffect(new PotionEffect(e.type(), e.ticks(), e.amplifier(), true, true, true));
    }

    // ------------------------------------------------------- custom abilities

    public Buff lifestealOf(UUID id) {
        Buff b = lifesteal.get(id);
        if (b == null) return null;
        if (b.until() < System.currentTimeMillis()) {
            lifesteal.remove(id);
            return null;
        }
        return b;
    }

    public boolean isAwakened(UUID id) {
        Long u = awakened.get(id);
        return u != null && u > System.currentTimeMillis();
    }

    /** Spinning flame/end-rod ring shown while Ruby Awakening is active. */
    public void awakenFx(Player p) {
        double t = System.currentTimeMillis() / 250.0;
        Location base = p.getLocation();
        for (int k = 0; k < 3; k++) {
            double ang = t + k * (Math.PI * 2 / 3);
            Location l = base.clone().add(Math.cos(ang) * 1.1, 0.3 + k * 0.7, Math.sin(ang) * 1.1);
            p.getWorld().spawnParticle(Particle.FLAME, l, 2, 0.02, 0.02, 0.02, 0.0);
        }
        p.getWorld().spawnParticle(Particle.END_ROD, base.clone().add(0, 2.2, 0), 1, 0.15, 0.1, 0.15, 0.0);
    }

    private static boolean free(Location l) {
        Block feet = l.getBlock();
        Block head = l.clone().add(0, 1, 0).getBlock();
        return feet.isPassable() && head.isPassable() && !feet.isLiquid() && !head.isLiquid();
    }

    /** Teleport forward; the ray stops at walls so nobody can blink through blocks. */
    private boolean blink(Player p, AbilityDef a) {
        double range = Math.max(2.0, a.raw().getDouble("range", 10.0));
        World w = p.getWorld();
        Location eye = p.getEyeLocation();
        Vector dir = eye.getDirection().normalize();
        RayTraceResult hit = w.rayTraceBlocks(eye, dir, range, FluidCollisionMode.NEVER, true);
        double dist = range;
        if (hit != null) dist = Math.max(0.0, eye.toVector().distance(hit.getHitPosition()) - 0.6);
        PlayerData d = plugin.ruby().cached(p.getUniqueId());
        for (double step = dist; step >= 1.0; step -= 0.5) {
            Location target = p.getLocation().add(dir.clone().multiply(step));
            if (!free(target) || !w.getWorldBorder().isInside(target)) continue;
            if (d != null) plugin.ruby().level(d.level).particle().play(p.getLocation(), 10);
            p.teleport(target);
            p.setFallDistance(0f);
            if (d != null) plugin.ruby().level(d.level).particle().play(target, 10);
            return true;
        }
        plugin.messages().send(p, "blink-blocked");
        return false;
    }

    /** Shockwave around the caster. Uses normal damage so PvP/region plugins and combat tag still apply. */
    public void nova(Player p, ConfigurationSection c) {
        double r = Math.max(1.0, c.getDouble("radius", 6.0));
        double dmg = Math.max(0.0, c.getDouble("damage", 6.0));
        double kb = c.getDouble("knockback", 1.3);
        int slow = c.getInt("slow-seconds", 3);
        int cap = Math.max(1, c.getInt("max-targets", 10));
        Team team = p.getScoreboard().getEntryTeam(p.getName());
        int hit = 0;
        for (Entity e : p.getNearbyEntities(r, r, r)) {
            if (hit >= cap) break;
            if (!(e instanceof LivingEntity le) || e instanceof ArmorStand || e.equals(p)) continue;
            if (e instanceof Villager || e instanceof WanderingTrader) continue;
            if (e instanceof Tameable pet && pet.isTamed()) continue;
            if (le.getLocation().distanceSquared(p.getLocation()) > r * r) continue;
            if (e instanceof Player o) {
                if (o.getGameMode() == GameMode.CREATIVE || o.getGameMode() == GameMode.SPECTATOR) continue;
                Team ot = o.getScoreboard().getEntryTeam(o.getName());
                if (team != null && ot != null && team.getName().equals(ot.getName())) continue;
            }
            le.damage(dmg, p);
            Vector push = le.getLocation().toVector().subtract(p.getLocation().toVector()).setY(0);
            if (push.lengthSquared() > 1.0E-4) push.normalize().multiply(kb);
            else push = new Vector(0, 0, 0);
            push.setY(0.4);
            le.setVelocity(push);
            if (slow > 0 && e instanceof Player) le.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, slow * 20, 1));
            hit++;
        }
        Location base = p.getLocation().add(0, 0.2, 0);
        for (int i = 0; i < 48; i++) {
            double ang = Math.PI * 2 * i / 48;
            for (double f : new double[] {0.5, 0.9}) {
                p.getWorld().spawnParticle(Particle.FLAME,
                        base.clone().add(Math.cos(ang) * r * f, 0, Math.sin(ang) * r * f), 1, 0.0, 0.0, 0.0, 0.02);
            }
        }
    }

    public boolean phoenixEnabled(PlayerData d) {
        ConfigurationSection c = plugin.getConfig().getConfigurationSection("phoenix");
        return c != null && c.getBoolean("enabled", true) && d.level >= c.getInt("min-level", 10);
    }

    /** Level-10 passive: survive a lethal hit once per cooldown. @return true if death was prevented. */
    public boolean tryPhoenix(Player p, PlayerData d) {
        if (!phoenixEnabled(d)) return false;
        ConfigurationSection c = plugin.getConfig().getConfigurationSection("phoenix");
        if (!p.hasPermission("rubysteal.ability." + PHOENIX)) return false;
        if (plugin.getConfig().getStringList("abilities.disabled-worlds").contains(p.getWorld().getName())) return false;
        long now = System.currentTimeMillis();
        Long exp = d.cooldowns.get(PHOENIX);
        if (exp != null && exp > now) return false;
        d.cooldowns.put(PHOENIX, now + Math.max(0, c.getInt("cooldown-seconds", 600)) * 1000L);

        AttributeInstance attr = p.getAttribute(Attribute.MAX_HEALTH);
        double max = attr == null ? 20.0 : attr.getValue();
        p.setHealth(Math.max(1.0, Math.min(max, max * c.getDouble("heal-fraction", 0.5))));
        p.setFireTicks(0);
        p.setFallDistance(0f);
        for (PotionEffectType bad : new PotionEffectType[] {PotionEffectType.POISON, PotionEffectType.WITHER,
                PotionEffectType.SLOWNESS, PotionEffectType.WEAKNESS, PotionEffectType.BLINDNESS,
                PotionEffectType.NAUSEA, PotionEffectType.MINING_FATIGUE}) {
            p.removePotionEffect(bad);
        }
        int guard = Math.max(1, c.getInt("protect-seconds", 3)) * 20;
        p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, guard, 4, true, true, true));
        p.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 160, 1, true, true, true));
        p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 100, 1, true, true, true));
        p.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 200, 0, true, true, true));
        nova(p, c);
        Location l = p.getLocation().add(0, 1, 0);
        p.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, l, 80, 0.6, 1.0, 0.6, 0.4);
        p.getWorld().playSound(p.getLocation(), "item.totem.use", 1f, 1f);
        plugin.messages().send(p, "phoenix-rebirth");
        plugin.ruby().saveAsync(d);
        return true;
    }
}
